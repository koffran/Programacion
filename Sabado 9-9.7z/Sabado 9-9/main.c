#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAM 3

int mostrarMenu(char[]);

int main()
{
    int codigo[TAM]={1,2,3}, auxInt;
    int stock[TAM]={5,15,24};
    float precio[TAM]={2.5,7.44,4.65}, auxFloat;
    char descripcion[TAM][50]={"pitusas","manaos","ottone"}, auxString[100];
    int opcion;
    int i, j;

    do
    {
        opcion = mostrarMenu("1.Alta\n2.Mostrar\n5.Salir\nElija una opcion: ");
        switch(opcion)
        {
            case 1:
                for(i=0; i<TAM; i++)
                {
                    if(codigo[i]==0)
                    {
                        printf("Ingrese codigo:");
                        scanf("%d",&codigo[i]);
                        printf("Ingrese descripcion:");
                        fflush(stdin);
                        gets(descripcion[i]);
                        printf("Ingrese precio:");
                        scanf("%f",&precio[i]);
                        printf("Ingrese stock:");
                        scanf("%d",&stock[i]);
                        break;
                    }

                }
            break;
            case 2:
                for(i=0; i<TAM; i++)
                {
                    if(codigo[i]!=0)
                    {
                         printf("%d--%s--%d--%f\n", codigo[i], descripcion[i], stock[i], precio[i]);
                    }

                }
            break;

            case 3:
                for(i=0; i<TAM-1; i++)
                {
                    for(j=i+1; j<TAM; j++)
                    {
                        if(strcmp(descripcion[i], descripcion[j])>0)
                        {
                            strcpy(auxString,descripcion[i]);
                            strcpy(descripcion[i], descripcion[j]);
                            strcpy(descripcion[j],auxString);

                            auxInt = codigo[i];
                            codigo[i] = codigo[j];
                            codigo[j] = auxInt;

                             auxInt = stock[i];
                            stock[i] = stock[j];
                            stock[j] = auxInt;

                              auxFloat = precio[i];
                            precio[i] = precio[j];
                            precio[j] = auxFloat;


                        }
                    }
                }

                break;
        }
    }while(opcion!=5);



    return 0;
}

int mostrarMenu(char texto[])
{
    int opcion;
    printf("%s", texto);
    scanf("%d", &opcion);

    return opcion;
}
